package br.com.joaocarloslima;

public enum Direcao {
    CIMA, BAIXO, ESQUERDA, DIREITA;
}
